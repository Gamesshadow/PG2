﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {

        static void Main(string[] args)
        {
            string[] options = { "1: The Speech", "2: List of Words", "3: Show Histogram", "4: Search for Word", "5: Remove Word", "6: Exit" };
            string speech = Input.GetSpeech();
            bool exit = true;
            int choice = 0;
  
            char [] trash = new char[] {'.', ',', ';', ':', '!', '-', ' ', '\n', '\t', '\r'};   
            string[] kept = speech.ToLower().Split(trash, StringSplitOptions.RemoveEmptyEntries);
            List<string> output = new List<string>(kept);
            Dictionary<string, int> result = new Dictionary<string, int>();
            {
                for (int i = 0; i < kept.Length; i++)
                {
                    if (result.ContainsKey(kept[i]))
                    {
                        int count = result[kept[i]];
                        result[kept[i]] = count + 1;
                    }
                    else
                    {
                        result.Add(kept[i], 1);
                    }
                }
            }

            while (exit == true)
            {
                Input.ReadChoice("Choose an option: ", options, out choice);
                switch (choice)
                {                    
                    case 1:
                        Console.Clear();
                        Console.WriteLine(speech);
                        Console.WriteLine("Press any key to continue..");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 2:
                        Console.Clear();
                        foreach (var item in output)
                        {
                            Console.WriteLine(item);    
                        }
                        Console.WriteLine("Press any key to continue..");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 3:
                        Console.Clear();
                        
                        foreach (KeyValuePair<string, int> item in result)
                        {
                            //Console.WriteLine(result.OrderByDescending(x => x.Value).ToList());
                            Console.Write(item.Key);
                            Console.CursorLeft = 14;
                            for (int i = 0; i < item.Value; i++)
                            {
                                Console.BackgroundColor = ConsoleColor.Magenta;
                                Console.Write("*");
                                Console.ResetColor();
                            }
                            Console.WriteLine(item.Value);
                        }
                        Console.WriteLine("Press any key to continue..");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 4:
                        Console.Clear();
                        string response = string.Empty;
                        Input.ReadString("What would you like to search for?", ref response);
                        Console.Clear();
                        foreach (KeyValuePair<string , int> item in result)
                        {
                            if (response == item.Key)
                            {
                                Console.WriteLine(item.Key);
                                for (int i = 0; i < item.Value; i++)
                                {
                                    
                                    Console.BackgroundColor = ConsoleColor.Magenta;
                                    Console.Write("*");
                                    Console.ResetColor();
                                }
                                Console.WriteLine(item.Value);
                            }
                            else
                            {
                                Console.WriteLine(response + " is not found.");
                            }
                            break;
                        }
                        Console.WriteLine("Press any key to continue..");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 5:
                        Console.Clear();
                        string input = string.Empty;
                        Input.ReadString("What would you like to remove?", ref input);
                        RemoveItem(input, result);               
                        Console.WriteLine("Press any key to continue..");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 6:
                        exit = false;
                        break;
                }
            }

        }
        public static void RemoveItem(string input, Dictionary<string, int> result)
        {
            bool removeitem = false;
            string remove = string.Empty;
            if (removeitem)
            {
                Console.WriteLine(input + " was removed.");
            }
            else
            {
                Console.WriteLine(input + " is not found in the current document");
            }
            
        }
    }
}
